#include <stdio.h>
#include <stdlib.h>

typedef struct stu_det
{
    char first_name[15];
    char last_name[15];
    unsigned blood_type;
    unsigned branch;
    unsigned year;
    unsigned height;        //Height is in cm
    unsigned weight;        //Weight in Kg
}student_database;

enum blood_group{ANEGATIVE, BNEGATIVE, ABNEGATIVE, ONEGATIVEn, APOSITIVE, BPOSITIVE, ABPOSITIVE, OPOSITIVE};
enum branch{AI, BM, BT, CHE, CHY, CSE, EE, ES, MA, ME, MSME};



int main()
{
    student_database stu_data[1000];     //Database
    char bloodgroup[8][12] = {"ANEGATIVE", "BNEGATIVE", "ABNEGATIVE", "ONEGATIVE", "APOSITIVE", "BPOSITIVE", "ABPOSITIVE", "OPOSITIVE"};
    char branch[11][5] = {"AI", "BM", "BT", "CHE", "CHY", "CSE", "EE", "ES", "MA", "ME", "MSME"};
    for (int i = 0; i < 1000; i++)
    {
        scanf("%s %s %u %u %u %u %u\n", stu_data[i].first_name, stu_data[i].last_name, &stu_data[i].blood_type, &stu_data[i].branch, &stu_data[i].year, &stu_data[i].height, &stu_data[i].weight);
    }

    //Q1a Printing the databse with branch and bloodgroups as readable strings
    for (int i = 0; i < 1000; i++)
    {
        printf("\n%s %s %s %s %u year %u cm %u Kg\n", stu_data[i].first_name, stu_data[i].last_name, bloodgroup[stu_data[i].blood_type], branch[stu_data[i].branch], stu_data[i].year, stu_data[i].height, stu_data[i].weight);
    }
    //End of Q1a

    //Q1b Printing the details of tallest and shortest student in the database
    unsigned min_height, min_ht_index;              //min_height: to store min height; min_ht_index to store INDEX of min height
    unsigned max_height, max_ht_index;              //max_height: to store max height; max_ht_index to store INDEX of max height
    min_height = max_height = stu_data[0].height;

    //Loop to find the tallest and shortest students in the given student database
    for (int j = 0; j < 1000; j++)
    {
        if(min_height > stu_data[j].height)
        {
            min_height = stu_data[j].height;
            min_ht_index = j;
        }
        if(max_height < stu_data[j].height)
        {
            max_height = stu_data[j].height;
            max_ht_index = j;
        }
    }
    printf("\nShortest \n%s %s %s %s %u year %u cm %u Kg\n", stu_data[min_ht_index].first_name, stu_data[min_ht_index].last_name, bloodgroup[stu_data[min_ht_index].blood_type], branch[stu_data[min_ht_index].branch], stu_data[min_ht_index].year, stu_data[min_ht_index].height, stu_data[min_ht_index].weight);
    printf("\nTallest \n%s %s %s %s %u year %u cm %u Kg\n", stu_data[max_ht_index].first_name, stu_data[max_ht_index].last_name, bloodgroup[stu_data[max_ht_index].blood_type], branch[stu_data[max_ht_index].branch], stu_data[max_ht_index].year, stu_data[max_ht_index].height, stu_data[max_ht_index].weight);
    //End of Q1b

    /*Q1c Print student records for heaviest and lightest students (in terms of weight) for each branch and
    year. Total of 11 branch and 4 years are there so there would be 88 such records printed.*/

    unsigned min_weight[5][12];            //Array to store minimum weight in a branch in a year
    unsigned max_weight[5][12];            //Array to store maximum weight in a branch in a year
    unsigned min_wt_index[5][12];             //Array to store the INDEX of minimum weight in a branch in a year
    unsigned max_wt_index[5][12];             //Array to store the INDEX of maximum weight in a branch in a year


    //Loop to initialize all the min and max weights of students
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 11; j++)
        {
            min_weight[i][j] = 110;
            max_weight[i][j] = 5;
        }
    }

    //Loop to find heaviest and lightest weighing students in a branch in a year
    for (int i = 0; i < 1000; i++)
    {
                if (min_weight[stu_data[i].year][stu_data[i].branch] > stu_data[i].weight)
                {
                    min_weight[stu_data[i].year][stu_data[i].branch] = stu_data[i].weight;
                    min_wt_index[stu_data[i].year][stu_data[i].branch] = i;
                }

                if (max_weight[stu_data[i].year][stu_data[i].branch] < stu_data[i].weight)
                {
                    max_weight[stu_data[i].year][stu_data[i].branch] = stu_data[i].weight;
                    max_wt_index[stu_data[i].year][stu_data[i].branch] = i;
                }

    }
    
    //Loop to print heaviest and lightest weighing students in a branch in a year
    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 11; j++)
        {
            printf("\nHeaviest in %s branch in %u year is:\n%s %s %s %u cm %u Kg\n", branch[stu_data[max_wt_index[i][j]].branch], stu_data[max_wt_index[i][j]].year, stu_data[max_wt_index[i][j]].first_name, stu_data[max_wt_index[i][j]].last_name, bloodgroup[stu_data[max_wt_index[i][j]].blood_type], stu_data[max_wt_index[i][j]].height, stu_data[max_wt_index[i][j]].weight);
            printf("\nLightest in %s branch in %u year is:\n%s %s %s %u cm %u Kg\n", branch[stu_data[min_wt_index[i][j]].branch], stu_data[min_wt_index[i][j]].year, stu_data[min_wt_index[i][j]].first_name, stu_data[min_wt_index[i][j]].last_name, bloodgroup[stu_data[min_wt_index[i][j]].blood_type], stu_data[min_wt_index[i][j]].height, stu_data[min_wt_index[i][j]].weight);
            
        }
    }
    //End of Q1.c
}//End of main