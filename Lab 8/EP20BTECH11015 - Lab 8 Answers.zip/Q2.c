/*Q2. Define a struct xypoint_t to represent points in x,y coordinate system and rtpoint_t to represent
points in r,theta coordinate system. Use double for all coordinates.
(a) write a function that accepts xypoint_t as a parameter and returns rtpoint_t (the coordinates of the
same point in r,theta system). Test this function by writing appropriate testing code in main()
(b) write a function that accepts rtpoint_t and returns corresponding xypoint_t. Test this function by
writing appropriate testing code in main()*/
#include <stdio.h>
#include <math.h>

typedef struct xypoint_t        //Composite type to represent points in x,y or Cartesian coordinate system
{
    double x;
    double y;
}xypoint_t;

typedef struct rtpoint_t        //Composite type to represent points in r,theta or Polar coordinate system
{
    double radius;
    double theta;               //Inclination of line in Radians
}rtpoint_t;

rtpoint_t cartesian_to_polar(xypoint_t inp);            /*Function that accepts xypoint_t (the coordinates of a point in x,y system) as a parameter
                                                          and returns corresponding rtpoint_t (the coordinates of the same point in r,theta system).*/

xypoint_t polar_to_cartesian(rtpoint_t inp);            /*Function that accepts rtpoint_t (the coordinates of a point in x,y system) as a parameter  
                                                          and returns corresponding xypoint_t (the coordinates of a point in r,theta system).*/

int main()
{
    //For Cartesian input (x , y) and Polar output (r , t)
    xypoint_t cartesian_input;
    printf("\nEnter the coo-radinates of a point in cartesian system");
    printf("\nX-coord: ");
    scanf("%lf", & cartesian_input.x);
    printf("n-coord: ");
    scanf("%lf", & cartesian_input.y);
    printf("\nThis point in polar system has coordinates (r , theta) = (%.4lf , %.4lf)", cartesian_to_polar(cartesian_input).radius, cartesian_to_polar(cartesian_input).theta);

    //For Polar input (r , t) and cartesian output (x , y)
    rtpoint_t polar_input;
    printf("\nEnter the coo-radinates of a point in polar system");
    printf("\nRadius: ");
    scanf("%lf", & polar_input.radius);
    printf("\nInclination: (in radians) ");
    scanf("%lf", & polar_input.theta);
    printf("\nThis point in polar system has coordinates (x , y) = (%.4lf , %.4lf)", polar_to_cartesian(polar_input).x, polar_to_cartesian(polar_input).y);

}

/*Function that accepts xypoint_t (the coordinates of a point in x,y system) as a parameter 
and returns corresponding rtpoint_t (the coordinates of the same point in r,theta system).*/
rtpoint_t cartesian_to_polar(xypoint_t inp)
{
    rtpoint_t op;
    op.radius = sqrt((pow(inp.x , 2) + pow(inp.y, 2)));
    op.theta = atan(inp.y / inp.x);
    return op;
}

/*Function that accepts rtpoint_t (the coordinates of a point in x,y system) as a parameter  
and returns corresponding xypoint_t (the coordinates of a point in r,theta system).*/
xypoint_t polar_to_cartesian(rtpoint_t inp)
{
    xypoint_t op;
    op.x = inp.radius * cos(inp.theta);
    op.y = inp.radius * sin(inp.theta);
    return op;
}

